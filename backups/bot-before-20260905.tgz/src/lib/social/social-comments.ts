/**
 * Facebook and Instagram comment/mention automation — the same rules as DMs,
 * scoped down: a comment reply is public, so it is always short, and an
 * escalated comment is never auto-answered even when DM automation is fully
 * automatic for this tenant.
 */

import { currentTenant } from "@/lib/tenant"
import { createAuditLog } from "@/lib/slots-server"
import { messengerAdapter } from "@/lib/social/messenger-adapter"
import { instagramAdapter } from "@/lib/social/instagram-adapter"
import { detectSocialEscalation, generateSocialReply, canAutoSendReply, type Tone } from "@/lib/social/social-ai"
import type { InboundSocialComment, SocialChannel } from "@/lib/social/types"

function adapterFor(channel: SocialChannel) {
  return channel === "FACEBOOK" ? messengerAdapter : instagramAdapter
}

export async function processInboundSocialComment(inbound: InboundSocialComment): Promise<void> {
  const { db } = await import("@/lib/db")
  const tenant = currentTenant()
  if (!tenant?.tenantId) return

  const existing = await db.message.findUnique({ where: { externalId: inbound.commentId } })
  if (existing) return

  const settings = await db.socialAutomationSettings.findUnique({
    where: { tenantId_channel: { tenantId: tenant.tenantId, channel: inbound.channel } },
  })

  // The comment is logged either way — visible in the inbox as its own kind
  // of conversation row — but nothing is drafted or sent without automation on.
  const customer = await db.customer.upsert({
    where: { tenantId_socialId: { tenantId: tenant.tenantId, socialId: inbound.fromExternalId } },
    create: {
      tenantId: tenant.tenantId, socialId: inbound.fromExternalId,
      phone: `social:${inbound.channel.toLowerCase()}:${inbound.fromExternalId}`, name: inbound.fromName,
      source: inbound.channel,
    },
    update: inbound.fromName ? { name: inbound.fromName } : {},
  })

  let conversation = await db.conversation.findFirst({
    where: { customerId: customer.id, channel: inbound.channel, externalUserId: inbound.parentPostId || inbound.commentId },
  })
  if (!conversation) {
    conversation = await db.conversation.create({
      data: {
        tenantId: tenant.tenantId, customerId: customer.id, customerPhone: customer.phone,
        customerName: inbound.fromName, channel: inbound.channel, externalUserId: inbound.commentId,
        status: "OPEN", labels: ["COMMENT"],
      },
    })
  }

  await db.message.create({
    data: {
      tenantId: tenant.tenantId, conversationId: conversation.id, customerId: customer.id,
      externalId: inbound.commentId, direction: "INBOUND", type: "TEXT", content: inbound.text, createdAt: inbound.timestamp,
    },
  })

  if (!settings?.enabled || !settings.commentAutoReplyEnabled) return

  const extraKeywords = Array.isArray(settings.handoffKeywords) ? (settings.handoffKeywords as string[]) : []
  const escalation = detectSocialEscalation(inbound.text, extraKeywords)
  if (escalation.escalate) {
    await db.conversation.update({ where: { id: conversation.id }, data: { automationPaused: true, labels: ["COMMENT", escalation.reason || "ESCALATED"] } })
    await createAuditLog({ action: "SOCIAL_COMMENT_ESCALATED", entity: "Conversation", entityId: conversation.id, details: escalation })
    return
  }

  const account = await db.socialAccount.findFirst({ where: { tenantId: tenant.tenantId, channel: inbound.channel, isActive: true } })
  if (!account) return

  const tenantRow = await db.tenant.findUnique({ where: { id: tenant.tenantId }, select: { name: true } })
  let replyText: string
  try {
    replyText = await generateSocialReply({
      message: inbound.text, businessName: tenantRow?.name || "",
      businessInfo: (settings.businessInfo as Record<string, unknown>) || null,
      customInstructions: (settings.customInstructions || "") + " This is a public comment reply — keep it to one short sentence.",
      tone: settings.tone as Tone, customTone: settings.customTone, language: "en", history: [],
    })
  } catch (error) {
    console.error("Comment reply generation failed:", error)
    return
  }

  const { decryptSecret } = await import("@/lib/secret-box")
  const canAutoSend = canAutoSendReply(settings, false)

  if (!canAutoSend) {
    await db.message.create({
      data: { tenantId: tenant.tenantId, conversationId: conversation.id, direction: "BOT", type: "TEXT", content: replyText, status: "DRAFT", isAiGenerated: true },
    })
    return
  }

  const result = await adapterFor(inbound.channel).replyToComment(decryptSecret(account.accessToken), inbound.commentId, replyText)
  await db.message.create({
    data: {
      tenantId: tenant.tenantId, conversationId: conversation.id, direction: "BOT", type: "TEXT",
      content: replyText, status: result.ok ? "SENT" : "FAILED", isAiGenerated: true, externalId: result.externalMessageId,
    },
  })
}
