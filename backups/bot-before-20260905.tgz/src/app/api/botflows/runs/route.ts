import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { currentTenant } from "@/lib/tenant"
import { withErrors } from "@/lib/api-handler"
import { withModule } from "@/lib/entitlements"

export const GET = withErrors(withModule("FLOWS", async (request: NextRequest) => {
  const tenant = currentTenant(); if (!tenant?.tenantId) return NextResponse.json({ error: "Workspace context required" }, { status: 401 })
  const status = new URL(request.url).searchParams.get("status")
  const runs = await db.flowRun.findMany({ where: { tenantId: tenant.tenantId, ...(status ? { status } : {}) }, include: { flow: { select: { id: true, name: true } } }, orderBy: { startedAt: "desc" }, take: 100 })
  return NextResponse.json({ runs })
}))
